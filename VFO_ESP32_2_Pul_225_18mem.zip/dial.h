/* 
 * File:   dial.h
 * Author: JF3HZB / T.UEBO
 *
 * Created on 2019/02/10, 22:13
 */


#ifndef DIAL_H
#define	DIAL_H

void init_Dial(void);
void Dial(long freq);
void dot(float, float);

void Sel_font12(void);
void Sel_font14(void);
void Sel_font16(void);

#endif	/* DIAL_H */
